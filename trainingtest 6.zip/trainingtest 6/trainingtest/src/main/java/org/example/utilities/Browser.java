package org.example.utilities;

public enum Browser {
    Chrome,
    InternetExplorer,
    FireFox

}
