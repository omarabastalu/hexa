package org.example.utilities;

public enum LocatorType {
    id,
    xpath,
    cssSelector,
    name
}
